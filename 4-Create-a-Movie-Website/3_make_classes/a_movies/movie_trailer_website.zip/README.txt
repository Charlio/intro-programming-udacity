-- Movie Trailer Website --
    a single-page wesite containing information of selected movies,
    for each movie, there is a poster, the movie name, and a link
    to its official trailer on youtube
   
-- Installation --
    * unzip the zip file in the folder: movie_trailer_website.zip
    * you will see four files: media.py, fresh_tomatoes.py, entertainment_center.py README.txt
    * open a terminal on mac/linux or git bash on windows
    * change directory to the folder containing these three files
    * type in the shell: python entertainment_center.py
    * the website will open automatically in your default browser
    
-- Usage --
    * on the website you will see posters and movie names of six selected movies
    * each movie is clickable, click one will open the corresponding official trailer
      on youtube
    * enjoy your movies